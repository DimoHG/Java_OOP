package celebration;

public interface Birthable {

    String getBirthDate();
}
