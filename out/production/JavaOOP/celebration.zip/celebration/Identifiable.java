package celebration;

public interface Identifiable {
    String getId();
}
