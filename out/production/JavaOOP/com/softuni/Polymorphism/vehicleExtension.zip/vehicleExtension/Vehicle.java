package com.softuni.Polymorphism.vehicleExtension;

public interface Vehicle {
    String drive(double distance);
    void refuel(double liters);

}
