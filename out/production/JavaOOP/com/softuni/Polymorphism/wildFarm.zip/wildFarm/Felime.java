package com.softuni.Polymorphism.wildFarm;

public abstract class Felime extends Mammal{

    public Felime(String name, String type, double weight, String livingRegion) {
        super(name, type, weight, livingRegion);
    }

}
